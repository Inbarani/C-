﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Pokeri
{
    class Program
    {
        static void Main(string[] args)
        {
            //Luo uusi
            Poker pokeri = new Poker();

            //Lisää peliin ainakin yksi käsi jollekin pelaajalle (LisaaTyhjaKasi("omistaja"))
            pokeri.LisaaTyhjaKasi("Mikki");
            pokeri.LisaaTyhjaKasi("Hessu");

            //Jaa peliin kortit (JaaKortit())
            pokeri.JaaKortit();

            //Hae pelin kädet
            List<Kasi>kadet = pokeri.Kadet;
            string luettu;
            string[] tekstina;
            List<Kortti> poistettavat;


            foreach (Kasi kasi in kadet)
            {
                Console.WriteLine(kasi.Pelaaja);
                Console.WriteLine(kasi);
                Console.WriteLine("Anna poistettavien korttien numerot (välilyönti välissä):");
                luettu = Console.ReadLine();
                tekstina = luettu.Split();
                poistettavat = new List<Kortti>();
                Kortti pois;


                foreach (string tekstiluku in tekstina)
                {
                    pois = kasi.HaeKorttiPaikasta(int.Parse(tekstiluku));
                    poistettavat.Add(pois);

                }

                foreach (Kortti poistettava in poistettavat)
                {
                    kasi.PoistaKortti(poistettava);
                }

            }
            pokeri.JaaKortit();

            foreach (Kasi kasi in kadet)
            {
                Console.WriteLine(kasi.Pelaaja);
                Console.WriteLine(kasi);
            }


            Console.ReadLine();

        }
    }
}
