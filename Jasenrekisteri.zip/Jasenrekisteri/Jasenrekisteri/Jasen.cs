﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jasenrekisteri
{
    public class Jasen
    {
        public string Sukunimi { get; set; }
        public string Etunimi { get; set; }
        public string Osoite { get; set; }
        public string Postinumero { get; set; }
        public string Postitoimipaikka { get; set; }
        public int Liittymisvuosi { get; set; }
        public int Jasennumero { get; set; }
    }
}
